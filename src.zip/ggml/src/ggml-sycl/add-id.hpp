#ifndef GGML_SYCL_ADD_ID_HPP
#define GGML_SYCL_ADD_ID_HPP

#include "common.hpp"

void ggml_sycl_add_id(ggml_backend_sycl_context & ctx, ggml_tensor * dst);

#endif // GGML_SYCL_ADD_ID_HPP
